using Microsoft.VisualStudio.TestTools.UnitTesting;
using Payroll;
using System.Collections.Generic;

namespace PayrollTests
{
    [TestClass]
    public class PayRollTests
    {
        [TestMethod]
        public static void AddHourlyEmployeeTest()
        {
            //Should throw out of range exception when age is over 150.
            int Age = 1000;
            HourlyEmployee employee = new HourlyEmployee();
            employee.Age = Age;
            employee.FirstName = "Natalie";
            employee.LastName = "Ward";
            employee.EmployeeID = 1;
            employee.HoursWorked = 40;
            employee.HourlyPay = 17;

            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => Employee.GetAge(employee));
        }
        [TestMethod]
        public static void AddSalariedEmployeeTest()
        {
            //Should throw out of range exception when age is over 150.
            int Age = 1000;
            SalariedEmployee employee = new SalariedEmployee();
            employee.Age = Age;
            employee.FirstName = "Natalie";
            employee.LastName = "Ward";
            employee.EmployeeID = 1;
            employee.MonthlyPay = 40;

            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => Employee.GetAge(employee));
        }
        [TestMethod]
        public static void Selection3Test()
            //should throw out of range exception when selection is not 1, 2, or 3.
        {
            List<HourlyEmployee> Hourly = new List<HourlyEmployee>();
            List<SalariedEmployee> Salaried = new List<SalariedEmployee>();
            int Selection = 4;
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => Employee.Selection3(Selection, Hourly, Salaried));
        }
    }
}
