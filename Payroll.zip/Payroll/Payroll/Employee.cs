﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Payroll
{
    //Abstract Base-Class "Employee"
    public abstract class Employee
    {
        string firstName;
        string lastName;
        int age;
        int employeeID;
        public string FirstName
        {
            get { return firstName;  }
            set { firstName = value; }
        }
        public string LastName
        { 
            get { return lastName;  }
            set { lastName = value; }
        }
        public int Age
        { 
            get { return age;  }
            set { age = value; }
        }
        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        //4-arg constructor to accept+store data for employee
        public Employee()
        {
            FirstName = "";
            LastName = "";
            Age = 0;
            EmployeeID = 0;
        }

        //Name property that returns formatted name
        public static String GetName(String FirstName, String LastName)
        {
            return LastName + ", " + FirstName;
        }
        //Read-Only age property
        public static int GetAge(HourlyEmployee employee)
        {
            return employee.Age;
        }
        //Read-Only ID property
        public static int GetEmployeeID(HourlyEmployee employee)
        {
            return employee.EmployeeID;
        }
        //Read-Only age property
        public static int GetAge(SalariedEmployee employee)
        {
            return employee.Age;
        }
        //Read-Only ID property
        public static int GetEmployeeID(SalariedEmployee employee)
        {
            return employee.EmployeeID;
        }
            //Calculate Pay Method
        public static decimal CalculateGrossPay(decimal MonthlyPay)
        {
            decimal WeeklyPay = ((MonthlyPay / 30) * 7);
            return WeeklyPay;
        }
        public static decimal CalculateGrossPay(decimal HourlyPay, decimal HoursWorked)
        {
            decimal WeeklyPay = (((HourlyPay * HoursWorked) / 30) * 7);
            return WeeklyPay;
        }
        public static decimal CalculatePay(decimal GrossPay)
        {
            decimal NetPay = Decimal.Multiply(Decimal.Divide(GrossPay, 100M), 65.85M);
            return NetPay;
        }
        public static decimal CalculateFica(decimal GrossPay)
        {
            decimal Fica = Decimal.Multiply(Decimal.Divide(GrossPay, 100M), 7.65M);
            return Fica;
        }
        public static decimal CalculateFederal(decimal GrossPay)
        {
            decimal Federal = Decimal.Multiply(Decimal.Divide(GrossPay, 100M), 26.5M);
            return Federal;
        }
        public static void UserInput()
        {
            List<HourlyEmployee> Hourly = new List<HourlyEmployee>();
            List<SalariedEmployee> Salaried = new List<SalariedEmployee>();
            Console.WriteLine("Welcome to the Payroll Application");
            while (true)
            {
                Console.WriteLine("Press 1 to add Hourly Employee, Press 2 to add Salaried Employee, Press 3 to run Weekly Report");
                InputOptions(Hourly, Salaried);
            }
        }
        public static void InputOptions(List<HourlyEmployee> Hourly, List<SalariedEmployee> Salaried)
        {
            int Selection = int.Parse(Console.ReadLine());
            Selection1(Selection, Hourly);
            Selection2(Selection, Salaried);
            Selection3(Selection, Hourly, Salaried);
        }
        public static void Selection1(int Selection, List<HourlyEmployee> Hourly)
        {
            if (Selection == 1)
            {
                AddHourlyEmployee(Hourly);
            }
        }
        public static void Selection2(int Selection, List<SalariedEmployee> Salaried)
        {
            if (Selection == 2)
            {
                AddSalariedEmployee(Salaried);
            }
        }
        public static void Selection3(int Selection, List<HourlyEmployee> Hourly, List<SalariedEmployee> Salaried)
        {
            if (Selection == 3)
            {
                HourlyIndividualReport(Hourly);
                SalariedIndividualReport(Salaried);
            }
            else
            {
                throw new ArgumentOutOfRangeException("Selection", "Selection must be 1, 2, or 3.");
            }
        }
        public static void AddHourlyEmployee(List<HourlyEmployee> Hourly)
        {
            HourlyEmployee employee = new HourlyEmployee();
            Console.WriteLine("Enter Employee's First Name");
            employee.FirstName = Console.ReadLine();
            Console.WriteLine("Enter Employee's Last Name");
            employee.LastName = Console.ReadLine();
            Console.WriteLine("Enter Employee's Age");
            employee.Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee's ID");
            employee.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee's Hours Worked");
            employee.HoursWorked = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter Employee's Hourly Pay");
            employee.HourlyPay = Convert.ToDecimal(Console.ReadLine());
            Hourly.Add(employee);
            if (employee.Age > 150)
            {
                throw new ArgumentOutOfRangeException("age","Employee age must be under 150 years");
            }
            
        }
        public static void AddSalariedEmployee(List<SalariedEmployee> Salaried)
        {
            SalariedEmployee employee = new SalariedEmployee();
            Console.WriteLine("Enter Employee's First Name");
            employee.FirstName = Console.ReadLine();
            Console.WriteLine("Enter Employee's Last Name");
            employee.LastName = Console.ReadLine();
            Console.WriteLine("Enter Employee's Age");
            employee.Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee's ID");
            employee.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee's Monthly Salary");
            employee.MonthlyPay = Convert.ToDecimal(Console.ReadLine());
            Salaried.Add(employee);
            if (employee.Age > 150)
            {
                throw new ArgumentOutOfRangeException("age", "Employee age must be under 150 years");
            }
        }
        public static void HourlyIndividualReport(List<HourlyEmployee> Hourly)
        {
            
            decimal HourlyGross = 0;
            decimal HourlyNet = 0;
            decimal HourlyFica = 0;
            decimal HourlyFederal = 0;
            Console.WriteLine("Hourly Employees");
            Console.WriteLine("");
            foreach (var item in Hourly)
            {
                string Name = GetName(item.FirstName, item.LastName);
                decimal GrossPay = CalculateGrossPay(item.HoursWorked, item.HourlyPay);
                decimal NetPay = CalculatePay(GrossPay);
                decimal Fica = CalculateFica(GrossPay);
                decimal Federal = CalculateFederal(GrossPay);
                HourlyGross += GrossPay;
                HourlyNet += NetPay;
                HourlyFica += Fica;
                HourlyFederal += Federal;



                Console.WriteLine("Employee Name : " + Name);
                Console.WriteLine("Employee Age : " + item.Age);
                Console.WriteLine("Employee ID : " + item.EmployeeID);
                Console.WriteLine("Employee Hours Worked : " + item.HoursWorked);
                Console.WriteLine("Employee Hourly Pay : $" + Math.Round(item.HourlyPay, 2));
                Console.WriteLine("Employee Gross Weekly Pay : $" + Math.Round(GrossPay, 2));
                Console.WriteLine("Employee Net Weekly Pay : $" + Math.Round(NetPay, 2));
                Console.WriteLine("Employee FICA deduction : $" + Math.Round(Fica, 2));
                Console.WriteLine("Employee Federal Income Tax Deduction: $" + Math.Round(Federal, 2));
                Console.WriteLine("----------------------------------------------------------------------------------");
            }
            HourlyReport(HourlyGross, HourlyNet, HourlyFica, HourlyFederal);
        }
        public static void SalariedIndividualReport(List<SalariedEmployee> Salaried)
        {
            decimal SalariedGross = 0;
            decimal SalariedNet = 0;
            decimal SalariedFica = 0;
            decimal SalariedFederal = 0;
            Console.WriteLine("Salaried Employees");
            Console.WriteLine("");
            foreach (var item in Salaried)
            {
                string Name = GetName(item.FirstName, item.LastName);
                decimal GrossPay = CalculateGrossPay(item.MonthlyPay);
                decimal NetPay = CalculatePay(GrossPay);
                decimal Fica = CalculateFica(GrossPay);
                decimal Federal = CalculateFederal(GrossPay);
                SalariedGross += GrossPay;
                SalariedNet += NetPay;
                SalariedFica += Fica;
                SalariedFederal += Federal;
                Console.WriteLine("Employee Name : " + Name);
                Console.WriteLine("Employee Age : " + item.Age);
                Console.WriteLine("Employee ID : " + item.EmployeeID);
                Console.WriteLine("Employee Monthly Pay : $" + Math.Round(item.MonthlyPay, 2));
                Console.WriteLine("Employee Gross Weekly Pay : $" + Math.Round(GrossPay, 2));
                Console.WriteLine("Employee Net Weekly Pay : $" + Math.Round(NetPay, 2));
                Console.WriteLine("Employee FICA deduction : $" + Math.Round(Fica, 2));
                Console.WriteLine("Employee Federal Income Tax Deduction: $" + Math.Round(Federal, 2));
                Console.WriteLine("----------------------------------------------------------------------------------");
            }
            SalariedReport(SalariedGross, SalariedNet, SalariedFica, SalariedFederal);

        }
        public static void HourlyReport(decimal HourlyGross, decimal HourlyNet, decimal HourlyFica, decimal HourlyFederal)
        {
            Console.WriteLine("Hourly Totals:");
            Console.WriteLine("Gross Payroll: $" + Math.Round(HourlyGross, 2));
            Console.WriteLine("Net Payroll: $" + Math.Round(HourlyNet, 2));
            Console.WriteLine("FICA deductions: $" + Math.Round(HourlyFica, 2));
            Console.WriteLine("Federal Income Tax deductions: $" + Math.Round(HourlyFederal, 2));
            Console.WriteLine("----------------------------------------------------------------------------------");
        }
        public static void SalariedReport(decimal SalariedGross, decimal SalariedNet, decimal SalariedFica, decimal SalariedFederal)
        {
            Console.WriteLine("Salary Totals:");
            Console.WriteLine("Gross Payroll: $" + Math.Round(SalariedGross, 2));
            Console.WriteLine("Net Payroll: $" + Math.Round(SalariedNet, 2));
            Console.WriteLine("FICA deductions: $" + Math.Round(SalariedFica, 2));
            Console.WriteLine("Federal Income Tax deductions: $" + Math.Round(SalariedFederal, 2));
            Console.WriteLine("----------------------------------------------------------------------------------");
        }

    }
    //Sub-Class for Hourly Employees
    //accessibility and bring over properties from Employee
    public class HourlyEmployee : Employee
    {
        public decimal HoursWorked;
        public decimal HourlyPay;
        public HourlyEmployee()
        {
            FirstName = "";
            LastName = "";
            Age = 0;
            EmployeeID = 0;
            HoursWorked = 0;
            HourlyPay = 0;
        }
    }
    public class SalariedEmployee : Employee
    {
        public decimal MonthlyPay;
        public SalariedEmployee()
        {
            FirstName = "";
            LastName = "";
            Age = 0;
            EmployeeID = 0;
            MonthlyPay = 0;
        }
    }
}
