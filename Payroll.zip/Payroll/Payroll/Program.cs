﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Payroll
{
    public class Program
    {
        static void Main(string[] args)
        {
            Employee.UserInput();
        }
    }
}
